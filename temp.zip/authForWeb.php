<?php
@session_start();
@$SESSION_ID=$_SESSION['SESSION_ID']; 
?>