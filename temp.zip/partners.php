<?php 
	include("config.php");
	include("header.php");  
?>
<div id="service">
			<div class="container">
           <div class="box-body" style="background:white; margin-left:12px;">
				 <!--1--->
          <div class="row">
             <div class="col-md-3">
				 <div class="form-group">
              <center><img src="images/partner/1.jpg" height="100px;"></center>
              </div>
			  </div>
			  <div class="col-md-3">
              <div class="form-group">
			  <center><img src="images/partner/14.png" height="100px;"></center>
			 </div>
             </div>
			 <div class="col-md-3">
              <div class="form-group">
				<center><img src="images/partner/13.jpg" height="100px;"></center>
              </div>
             </div>
			 <div class="col-md-3">
              <div class="form-group">
			<center><img src="images/partner/2.png" height="100px;"></center>
              </div>
             </div>
		  </div>

			 <!--2--->
          <div class="row">
             <div class="col-md-3">
				 <div class="form-group">
              <center><img src="images/partner/27.png" height="100px;"></center>
              </div>
			  </div>
			  <div class="col-md-3">
              <div class="form-group">
			  <center><img src="images/partner/7.jpg" height="100px;"></center>
			 </div>
             </div>
			 <div class="col-md-3">
              <div class="form-group">
				<center><img src="images/partner/17.jpg" height="100px;"></center>
              </div>
             </div>
			 <div class="col-md-3">
              <div class="form-group">
			<center><img src="images/partner/25.jpg" height="100px;"></center>
              </div>
             </div>
		  </div>
		  
		   <!--3--->
          <div class="row">
             <div class="col-md-3">
				 <div class="form-group">
              <center><img src="images/partner/15.jpg" height="100px;"></center>
              </div>
			  </div>
			  <div class="col-md-3">
              <div class="form-group">
			  <center><img src="images/partner/8.png" height="100px;"></center>
			 </div>
             </div>
			 <div class="col-md-3">
              <div class="form-group">
				<center><img src="images/partner/4.png" height="100px;"></center>
              </div>
             </div>
			 <div class="col-md-3">
              <div class="form-group">
			<center><img src="images/partner/5.jpg" height="100px;"></center>
              </div>
             </div>
		  </div>
		  
		   <!--4--->
          <div class="row">
             <div class="col-md-3">
				 <div class="form-group">
              <center><img src="images/partner/24.jpg" height="100px;"></center>
              </div>
			  </div>
			  <div class="col-md-3">
              <div class="form-group">
			  <center><img src="images/partner/12.png" height="100px;"></center>
			 </div>
             </div>
			 <div class="col-md-3">
              <div class="form-group">
				<center><img src="images/partner/11.jpg" height="100px;"></center>
              </div>
             </div>
			 <div class="col-md-3">
              <div class="form-group">
			<center><img src="images/partner/10.png" height="100px;"></center>
              </div>
             </div>
		  </div>
		  
		   <!--5--->
          <div class="row">
		  <div class="col-md-3">
              <div class="form-group">
			  <center><img src="images/partner/23.jpg" height="100px;"></center>
			 </div>
             </div>
             <div class="col-md-3">
				 <div class="form-group">
				 <p>&nbsp;</p>
              <center><img src="images/partner/26.png" ></center>
              </div>
			  </div>
			  <div class="col-md-3">
				 <div class="form-group">
				 
              <center><img src="images/partner/28.jpg" height="100px;" ></center>
              </div>
			  </div>
			  <div class="col-md-3">
				 <div class="form-group">
				 
              <center><img src="images/partner/29.jpg" height="100px;"></center>
              </div>
			  </div>
			  
			  
			 
		  </div>
		  
		   <!--6--->
          
			
			
				
		  </div>
      </div>
</section>
</div>


<?php 
include("footer.php");
?>