<footer>
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-sm-7">
						<p>Maintain and Developed by PHP Poets IT Solutions Pvt. Ltd. </p>
					</div>
					<div class="col-md-4 col-sm-5">
						
					</div>
				</div>
			</div>
		</footer>
		<!-- end footer -->


		<!-- jQuery -->
		<script src="js/jquery.js"></script>
		<!-- bootstrap -->
		<script src="js/bootstrap.min.js"></script>
		<!-- isotope -->
		<script src="js/isotope.js"></script>
		<!-- images loaded -->
   		<script src="js/imagesloaded.min.js"></script>
   		<!-- wow -->
		<script src="js/wow.min.js"></script>
		<!-- smoothScroll -->
		<script src="js/smoothscroll.js"></script>
		<!-- jquery flexslider -->
		<script src="js/jquery.flexslider.js"></script>
		<!-- custom -->
		<script src="js/custom.js"></script>
        <!--	Date Picker -->
        <script src="assest/plugins/datepicker/bootstrap-datepicker.js"></script>
		<script src="assest/plugins/timepicker/bootstrap-timepicker.min.js"></script>
        <script>
		$('.datepicker').datepicker({
			  autoclose: true
		});
		$(".timepicker").timepicker({
		  showInputs: false
		});
		</script>

        </body>
</html>